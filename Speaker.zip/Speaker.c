/*

   This modul exports Sound function that produces a sound of a desired
   frequency and duration - similar to Beep function under Windows NT -
   with one exception - the Sound function works fine under Windows 9.x
   as well.

   (c) Bojan Jurca, February 4th 2000

      bojan.jurca@siol.ner
      http://www.stormpages.com/bojanjurca/

   Written for Lcc - a free C compiler written by Jacob Navia
   http://www.cs.virginia.edu/~lcc-win32/

*/


/* --- The following code comes from C:\lcc\lib\wizard\dll.tpl. */
#include <windows.h>

BOOL Win9x;

/*------------------------------------------------------------------------
 Procedure:     LibMain ID:1
 Purpose:       Dll entry point.Called when a dll is loaded or
                unloaded by a process, and when new threads are
                created or destroyed.
 Input:         hDllInst: Instance handle of the dll
                fdwReason: event: attach/detach
                lpvReserved: not used
 Output:        The return value is used only when the fdwReason is
                DLL_PROCESS_ATTACH. True means that the dll has
                sucesfully loaded, False means that the dll is unable
                to initialize and should be unloaded immediately.
 Errors:
------------------------------------------------------------------------*/
BOOL WINAPI __declspec(dllexport) LibMain(HINSTANCE hDLLInst, DWORD fdwReason, LPVOID lpvReserved)
{
    OSVERSIONINFO OsVersion;

    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // The DLL is being loaded for the first time by a given process.
            // Perform per-process initialization here.  If the initialization
            // is successful, return TRUE; if unsuccessful, return FALSE.

            // Check Windows version here
            OsVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
            GetVersionEx (&OsVersion);
            // Check if platform is Win32s, Windows 95 or Windows 98
            Win9x = ((OsVersion.dwPlatformId == VER_PLATFORM_WIN32s) || (OsVersion.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS));

            break;

        /* We're not going to use the rest of possibilities - comment them out

        case DLL_PROCESS_DETACH:
            // The DLL is being unloaded by a given process.  Do any
            // per-process clean up here, such as undoing what was done in
            // DLL_PROCESS_ATTACH.  The return value is ignored.


            break;
        case DLL_THREAD_ATTACH:
            // A thread is being created in a process that has already loaded
            // this DLL.  Perform any per-thread initialization here.  The
            // return value is ignored.

            break;
        case DLL_THREAD_DETACH:
            // A thread is exiting cleanly in a process that has already
            // loaded this DLL.  Perform any per-thread clean up here.  The
            // return value is ignored.

            break;

        */

    }
    return TRUE;
}


/*

   Lcc does not support _inp and _outp functions that would address
   processor I/O ports so I had to write them on my own. Let's just
   preserve some code space here for this two function and then we are going
   to insert a new machine code into a compiled .dll file for both of them later.

   Take a look at Disassembled.txt to see what needs to be done after compilation.

   If you're using a C compiler that can access processor I/O ports directly 
   (Visual C++ for example) you may not need to write this two fuctions.

*/

BYTE _inp (unsigned short port)
{
   return port ++; // some meaningles code just to see how Lcc address function parameters
}

void _outp (unsigned short port, BYTE value)
{
   port ++;  // some menaningles code just to see how Lcc address function parameters
   value ++;
}

/*

   The folowing code and coments (slightly changed) came from
   The Wite Group's Turbo C Bible:

      The IBM PC's speaker can be used to generate tone by programming it via the
      8255 chip at port address 61h and using the system timer (Intel 8254 chip) to
      control the speaker. Here is how it works. First you will set up the timer as an
      oscillator by sending the data byte B6h to the port 43h. Then you compute the
      ratio of the frequency of the sound you want and the frequency of the timer's
      clock frequency (1.19 MHz). Write this value to port 42h. Tell the 8255 chip to
      drive the speker under the control of the timer by reading the port 61h and
      writting the value back with the first two bits set to 1 (perform a logical OR with
      3). This gets the sound going. Let the sound continue as long as you wish. Shut
      the speaker off by reading port 61h and setting bits 0 and 1 to 0.

*/

#define TIMER_FREQ 1193180L   /* Timer freq = 1.99 MHz */
#define TIMER_COUNT 0x42      /* 8253 timer count */
#define TIMER_MODE 0x43       /* 8253 timer control port */
#define TIMER_OSC 0xb6        /* To use timer as oscilator */
#define OUT_8255 0x61         /* 8255 PPI output port adrs */
#define SPKRON 3              /* Bit 0 = control spkr by timer */
                              /* Bit 1 = speaker on/off */

void Win9xBeep (long dwFreq, long dwDuration)
{
   /* First read and save status of the 8255 chip */
   unsigned status = _inp (OUT_8255);

   /* Compute the ratio */
   unsigned ratio = (unsigned) (TIMER_FREQ / dwFreq);
   unsigned part_ratio;

   /* Put timer in oscilator mode */
   _outp (TIMER_MODE, TIMER_OSC);
   part_ratio = ratio & 0xff;        /* low byte of ratio */
   _outp (TIMER_COUNT, part_ratio);
   part_ratio = (ratio >> 8) & 0xff; /* high byte */
   _outp (TIMER_COUNT, part_ratio);

   /* Finally turn on speaker */
   _outp (OUT_8255, (status | SPKRON));

   Sleep (dwDuration);

   /* Now turn off speaker */
   status = _inp (OUT_8255);         /* get current status */
   _outp (OUT_8255, (status & ~SPKRON));
}


/*

   Exported Sound function uses Beep function under Windows NT and
   Win9xBeep functions under Windows 95/98.

*/

BOOL WINAPI __declspec(dllexport) Sound (long dwFreq, long dwDuration)
{
   if (Win9x)
      Win9xBeep (dwFreq, dwDuration);
   else
      Beep (dwFreq, dwDuration);

   return TRUE;
}
