Speaker C example.

Written by Bojan Jurca {
	bojan.jurca@siol.net
	http://www.stormpages.com/bojanjurca/
}

*************************************************************

This software is FREEWARE. You may use it as you see fit for 
your own projects but you may not re-sell the original or the 
source code. If you redistribute it you must include this 
disclaimer. 

No warranty express or implied, is given as to the use of this
program. Use at your own risk.

*************************************************************